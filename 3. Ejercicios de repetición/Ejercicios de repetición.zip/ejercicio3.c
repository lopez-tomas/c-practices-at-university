#include <stdio.h>

int main()
{
    int n, i;

    printf("Ingrese un numero entero positivo: ");
    scanf("%d", &i);

    for(i=1; i; i++);


    return 0;
}
