#include <stdio.h>

int sumar(int, int);
int restar(int, int);
int porcentaje(int, int);
int mcd(int, int);

int main(){

    int n1, n2, op;

    printf("Ingrese un numero: ");
    scanf("%d", n1);

    printf("\nIngrese un numero: ");
    scanf("%d", n2);

    do{
        printf("\n1. Sumar");
        printf("\n2. Restar");
        printf("\n3. Porcentaje");
        printf("\n4. MCD");
        printf("\n9. Salir");

        scanf("%d", op);

        switch(op){
        case 1:
            sumar(n1,n2);
            break;

        case 2:
            restar(n1,n2);
            break;

        case 3:
            porcentaje(n1,n2);
            break;

        case 4:
            mcd(n1, n2);
            break;
        }

    }while(op != 5);

    return 0;
}

sumar(int nro1, int nro2){
    int suma;

    suma = nro1 + nro2;

    return suma;
}

restar(int nro1, int nro2){
    int resta;

    if(nro1 > nro2){
        resta = nro1 - nro2;
    }else{
        resta = nro2 - nro1;
    }

    return resta;
}

porcentaje(int nro1, int nro2){
    int porcentaje;

    if(nro1 > nro2){
        porcentaje = (nro2 * 100)/nro1;
    }else{
        porcentaje = (nro1 * 100)/nro2;
    }

    return porcentaje;
}

int mcd(int nro1, int nro2){
    int resto, resto2;

    resto = a % b;

    if(resto == 0){
        return b;
    }else{

        do{

        resto2 = b % resto;

        }while(resto != 0);

        return resto;
    }
}
