#include <stdio.h>

int nuevoFormato(int, int, int);

int main(){
    int dia, mes, year, fecha;

    printf("Ingrese una fecha(DD/MM/AAAA): ");
    scanf("%d" "%d" "%d", &dia, &mes, &year);

    fecha = nuevoFormato(dia, mes, year);

    printf("%d", fecha);

    return 0;
}

int nuevoFormato(int d, int m, int y){
    int year2, mes2, fecha2;

    year2 = y * 10000;
    mes2 = m * 100;

    fecha2 = year2 + mes2 + d;

    return fecha2;

}
